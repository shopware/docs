<?php declare(strict_types=1);

namespace B2bRestApi;

use Shopware\Core\Framework\Plugin;

class B2bRestApi extends Plugin
{
}
