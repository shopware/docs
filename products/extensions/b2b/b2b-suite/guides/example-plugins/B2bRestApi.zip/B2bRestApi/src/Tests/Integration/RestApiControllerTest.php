<?php declare(strict_types=1);

namespace B2bRestApi\Test\Integration;

use PHPUnit\Framework\TestCase;
use Shopware\B2B\Common\Testing\ApiTestCaseTrait;

class B2bRestApiTest extends TestCase
{
    use ApiTestCaseTrait;

    public function test_it_routes_to_root(): void
    {
        $result = $this->query('GET', '/rest/api/enterprise');

        self::assertArrayHasKey('message', $result);
        self::assertEquals('hello enterprise', $result['message']);
    }
}
