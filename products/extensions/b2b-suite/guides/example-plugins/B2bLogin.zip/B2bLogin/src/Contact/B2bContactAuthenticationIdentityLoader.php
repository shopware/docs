<?php declare(strict_types=1);

namespace B2bLogin\Contact;

use Shopware\B2B\Common\IdValue;
use Shopware\B2B\Common\Repository\NotFoundException;
use Shopware\B2B\Contact\BridgePlatform\ContactAuthenticationIdentityLoader;
use Shopware\B2B\Contact\Framework\ContactIdentity;
use Shopware\B2B\Contact\Framework\ContactRepository;
use Shopware\B2B\Debtor\BridgePlatform\DebtorRepository;
use Shopware\B2B\Debtor\Framework\DebtorIdentity;
use Shopware\B2B\StoreFrontAuthentication\Framework\AbstractCredentialsEntity;
use Shopware\B2B\StoreFrontAuthentication\Framework\Identity;
use Shopware\B2B\StoreFrontAuthentication\Framework\LoginContextService;

class B2bContactAuthenticationIdentityLoader extends ContactAuthenticationIdentityLoader
{
    private B2bContactRepository $contactRepository;

    private DebtorRepository $debtorRepository;

    public function __construct(B2bContactRepository $contactRepository, DebtorRepository $debtorRepository)
    {
        $this->contactRepository = $contactRepository;
        $this->debtorRepository = $debtorRepository;
        parent::__construct($contactRepository, $debtorRepository);
    }

    public function fetchIdentityByStaffId(string $staffId, LoginContextService $contextService, bool $isApi = false): Identity
    {
        $entity = $this->contactRepository->fetchOneByStaffId($staffId);

        /** @var DebtorIdentity $debtorIdentity */
        $debtorIdentity = $this
            ->debtorRepository
            ->fetchIdentityById($entity->debtor->id, $contextService);

        $authId = $contextService->getAuthId(ContactRepository::class, $entity->id, $debtorIdentity->getAuthId());

        $this->contactRepository->setAuthId(IdValue::create($entity->id), $authId, $debtorIdentity->getOwnershipContext());

        return new ContactIdentity($authId, IdValue::create($entity->id), ContactRepository::TABLE_NAME, $entity, $debtorIdentity);
    }

    public function fetchIdentityByCredentials(AbstractCredentialsEntity $credentialsEntity, LoginContextService $contextService, bool $isApi = false): Identity
    {
        if (!isset($credentialsEntity->staffId) || !$credentialsEntity->staffId) {
            throw new NotFoundException('Unable to handle context');
        }

        return $this->fetchIdentityByStaffId($credentialsEntity->staffId, $contextService);
    }
}
