<?php declare(strict_types=1);

namespace Shopware\B2BTest\SwagB2bPlugin\Functional\Environment;

use PHPUnit\Framework\TestCase;
use Shopware\B2B\Common\Testing\WebTestCaseTrait;
use Shopware\B2B\Contact\Framework\ContactIdentity;
use Shopware\B2B\Debtor\Framework\DebtorIdentity;
use Shopware\B2BTest\B2bLogin\EnvironmentFixtures;
use function print_r;

class EnvironmentTest extends TestCase
{
    use WebTestCaseTrait;

    public function setUp(): void
    {
        $this->importFixture(new EnvironmentFixtures());
    }

    public function test_fails_for_unknown_user(): void
    {
        $client = $this->createClient();
        $this->getKernel()->getContainer()->get('front')->setResponse('Enlight_Controller_Response_ResponseTestCase');
        $client->request(
            'POST',
            'account/login/sTarget/account/sTargetAction/index',
            [
                'staffId' => 'foo',
                'password' => 'bar',
            ]
        );

        self::assertEquals(200, $client->getResponse()->getStatusCode());
        self::assertContains(
            'Ihre Zugangsdaten konnten keinem Benutzer zugeordnet werden',
            $client->getResponse()->getContent()
        );

        self::assertEquals(1, $client->getResponse()->headers->has('B2b-no-login'));
        self::assertFalse($client->getResponse()->headers->has('B2b-login'));
        self::assertEquals(200, $client->getResponse()->getStatusCode());
    }

    public function test_success_login_for_debtor(): void
    {
        $this->getKernel()->getContainer()->get('front')->setResponse('Enlight_Controller_Response_ResponseTestCase');
        $client = $this->createClient();
        $client->request(
            'POST',
            'account/login/sTarget/account/sTargetAction/index',
            [
                'staffId' => 'B-1',
                'password' => 'shopware',
            ]
        );
        self::assertEquals(302, $client->getResponse()->getStatusCode());

        $this->getKernel()->getContainer()->get('front')->setResponse('Enlight_Controller_Response_ResponseTestCase');
        $client->request('GET', 'account');
        self::assertNotContains(
            'Ihre Zugangsdaten konnten keinem Benutzer zugeordnet werden',
            $client->getResponse()->getContent()
        );
        self::assertEquals(
            302,
            $client->getResponse()->getStatusCode(),
            print_r($client->getResponse()->getStatusCode(), true)
        );

        self::assertNull($client->getResponse()->headers->get('B2b-login'));
        self::assertTrue(
            $this->getKernel()->getContainer()->get('b2b_front_auth.authentication_service')->is(
                DebtorIdentity::class
            )
        );
    }

    public function test_success_login_for_existing_contact(): void
    {
        $client = $this->createClient();
        $this->getKernel()->getContainer()->get('front')->setResponse('Enlight_Controller_Response_ResponseTestCase');
        $client->request(
            'POST',
            'account/login/sTarget/account/sTargetAction/index',
            [
                'staffId' => 'A-1',
                'password' => 'shopware',
            ]
        );
        self::assertEquals(302, $client->getResponse()->getStatusCode());

        $this->getKernel()->getContainer()->get('front')->setResponse('Enlight_Controller_Response_ResponseTestCase');
        $client->request('GET', 'account');
        self::assertEquals(302, $client->getResponse()->getStatusCode());
        self::assertNotContains(
            'Ihre Zugangsdaten konnten keinem Benutzer zugeordnet werden',
            $client->getResponse()->getContent()
        );
        self::assertTrue(
            $this->getKernel()->getContainer()->get('b2b_front_auth.authentication_service')->is(
                ContactIdentity::class
            )
        );
    }

    public function test_success_login_for_new_contact(): void
    {
        $client = $this->createClient();
        $this->getKernel()->getContainer()->get('front')->setResponse('Enlight_Controller_Response_ResponseTestCase');
        $client->request(
            'POST',
            'account/login/sTarget/account/sTargetAction/index',
            [
                'staffId' => 'A-3',
                'password' => 'shopware',
            ]
        );

        $this->getKernel()->getContainer()->get('front')->setResponse('Enlight_Controller_Response_ResponseTestCase');
        $client->request('GET', 'account');
        self::assertNotContains(
            'Ihre Zugangsdaten konnten keinem Benutzer zugeordnet werden',
            $client->getResponse()->getContent()
        );
        self::assertTrue(
            $this->getKernel()->getContainer()->get('b2b_front_auth.authentication_service')
                ->is(ContactIdentity::class)
        );
    }
}
