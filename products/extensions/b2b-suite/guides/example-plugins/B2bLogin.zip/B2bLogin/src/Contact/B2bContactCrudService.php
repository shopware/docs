<?php declare(strict_types=1);

namespace B2bLogin\Contact;

use Shopware\B2B\Acl\Framework\AclGrantContext;
use Shopware\B2B\Acl\Framework\AclRepository;
use Shopware\B2B\Common\Service\CrudServiceRequest;
use Shopware\B2B\Contact\Framework\ContactCrudService;
use Shopware\B2B\Contact\Framework\ContactEntity;
use Shopware\B2B\Contact\Framework\ContactPasswordActivationServiceInterface;
use Shopware\B2B\Contact\Framework\ContactPasswordProviderInterface;
use Shopware\B2B\Contact\Framework\ContactRepository;
use Shopware\B2B\Contact\Framework\ContactValidationService;
use Shopware\B2B\StoreFrontAuthentication\Framework\CredentialsBuilderInterface;
use Shopware\B2B\StoreFrontAuthentication\Framework\Identity;
use Shopware\B2B\StoreFrontAuthentication\Framework\LoginContextService;
use Shopware\B2B\StoreFrontAuthentication\Framework\OwnershipContext;
use Shopware\B2B\StoreFrontAuthentication\Framework\StoreFrontAuthenticationRepository;
use Shopware\B2B\StoreFrontAuthentication\Framework\TransferOwnerDataToContextOwnerService;
use Shopware\B2B\StoreFrontAuthentication\Framework\UserRepositoryInterface;
use function uniqid;

class B2bContactCrudService extends ContactCrudService
{
    private ContactRepository $contactRepository;

    private ContactValidationService $validationService;

    private AclRepository $aclRepository;

    private ContactPasswordProviderInterface $passwordProvider;

    public function __construct(
        ContactRepository $contactRepository,
        ContactValidationService $validationService,
        AclRepository $aclAddressRepository,
        ContactPasswordProviderInterface $passwordProvider,
        ContactPasswordActivationServiceInterface $contactPasswordActivationService,
        LoginContextService $loginContextService,
        array $aclAccessWriters,
        UserRepositoryInterface $userRepository,
        CredentialsBuilderInterface $credentialsBuilder,
        StoreFrontAuthenticationRepository $authRepository,
        TransferOwnerDataToContextOwnerService $transferOwnerDataToContextOwnerService
    ) {
        parent::__construct(
            $contactRepository,
            $validationService,
            $aclAddressRepository,
            $passwordProvider,
            $contactPasswordActivationService,
            $loginContextService,
            $aclAccessWriters,
            $userRepository,
            $credentialsBuilder,
            $authRepository,
            $transferOwnerDataToContextOwnerService
        );
        $this->contactRepository = $contactRepository;
        $this->validationService = $validationService;
        $this->aclRepository = $aclAddressRepository;
        $this->passwordProvider = $passwordProvider;
    }

    /**
     * @throws \Shopware\B2B\Common\Validator\ValidationException
     */
    public function create(
        CrudServiceRequest $request,
        Identity $identity,
        AclGrantContext $grantContext
    ): ContactEntity {
        $data = $request->getFilteredData();

        $ownershipContext = $identity->getOwnershipContext();

        $contact = new ContactEntity();

        $contact->setData($data);

        if (empty($contact->email)) {
            $contact->email = uniqid('', true);
        }

        $this->checkPassword($contact, $request, true);
        $this->passwordProvider->setPassword($contact, $request->requireParam('passwordNew'));

        $validation = $this->validationService
            ->createInsertValidation($contact);

        $this->testValidation($contact, $validation);

        $contact = $this->contactRepository
            ->addContact($contact, $ownershipContext);

        $this->aclRepository
            ->allowAll(
                $contact,
                [
                    $identity->getMainShippingAddress()->id,
                    $identity->getMainBillingAddress()->id,
                ]
            );

        return $contact;
    }

    /**
     * @throws \Shopware\B2B\Common\Validator\ValidationException
     */
    public function update(CrudServiceRequest $request, OwnershipContext $ownershipContext): ContactEntity
    {
        $data = $request->getFilteredData();
        $contact = new ContactEntity();
        $contact->setData($data);

        $this->checkPassword($contact, $request, false);

        if ($request->hasValueForParam('passwordNew')) {
            $this->passwordProvider->setPassword($contact, $request->requireParam('passwordNew'));
        }

        $validation = $this->validationService
            ->createUpdateValidation($contact, $ownershipContext);

        $this->testValidation($contact, $validation);

        if (empty($contact->email)) {
            $contact->email = uniqid('', true);
        }

        $this->contactRepository
            ->updateContact($contact, $ownershipContext);

        return $contact;
    }
}
