<?php declare(strict_types=1);

namespace B2bLogin\Contact;

use Shopware\B2B\Address\Framework\AddressRepositoryInterface;
use Shopware\B2B\Common\Validator\ValidationBuilder;
use Shopware\B2B\Common\Validator\Validator;
use Shopware\B2B\Contact\Framework\ContactEntity;
use Shopware\B2B\Contact\Framework\ContactPasswordProviderInterface;
use Shopware\B2B\Contact\Framework\ContactRepository;
use Shopware\B2B\Contact\Framework\ContactValidationService;
use Shopware\B2B\Debtor\Framework\DebtorRepositoryInterface;
use Shopware\B2B\StoreFrontAuthentication\Framework\CredentialsBuilderInterface;
use Shopware\B2B\StoreFrontAuthentication\Framework\OwnershipContext;
use Shopware\B2B\StoreFrontAuthentication\Framework\UserRepositoryInterface;
use Symfony\Component\Validator\Validator\ValidatorInterface;

class B2bContactValidationService extends ContactValidationService
{
    private ValidatorInterface $validator;

    private ContactRepository $contactRepository;

    private DebtorRepositoryInterface $debtorRepository;

    public function __construct(
        ValidationBuilder $validationBuilder,
        ValidatorInterface $validator,
        ContactRepository $contactRepository,
        UserRepositoryInterface $userRepository,
        CredentialsBuilderInterface $credentialsBuilder,
        AddressRepositoryInterface $addressRepository,
        ContactPasswordProviderInterface $passwordProvider,
        DebtorRepositoryInterface $debtorRepository
    ) {
        parent::__construct(
            $validationBuilder,
            $validator, $contactRepository,
            $userRepository,
            $credentialsBuilder,
            $addressRepository,
            $passwordProvider
        );

        $this->validator = $validator;
        $this->contactRepository = $contactRepository;
        $this->debtorRepository = $debtorRepository;
    }

    public function createInsertValidation(ContactEntity $contact, OwnershipContext $ownershipContext = null): Validator
    {
        $validation = $this->createCrudValidation($contact)
            ->validateThat('id', $contact->id)
                ->isBlank();

        if (empty($contact->email)) {
            return $validation->getValidator($this->validator);
        }

        return $validation->validateThat('email', $contact->email)
                ->isUnique(function () use ($contact) {
                    return 0 === $this->contactRepository->hasByEmail($contact->email);
                })
                ->isUnique(function () use ($contact) {
                    return !$this->debtorRepository->hasDebtorWithEmail($contact->email);
                })
                ->isNotBlank()
                ->isEmail()

            ->getValidator($this->validator);
    }

    public function createUpdateValidation(ContactEntity $contact, OwnershipContext $ownershipContext): Validator
    {
        $validation = $this->createCrudValidation($contact)
            ->validateThat('id', $contact->id)
                ->isNotBlank();

        if (empty($contact->email)) {
            return $validation->getValidator($this->validator);
        }

        return $validation->validateThat('email', $contact->email)
            ->isUnique(function () use ($contact) {
                return 2 > $this->contactRepository->hasByEmail($contact->email);
            })
            ->isUnique(function () use ($contact) {
                return 3 > $this->debtorRepository->fetchDebtorWithEmailCount($contact->email);
            })
            ->isEmail()
            ->getValidator($this->validator);
    }
}
