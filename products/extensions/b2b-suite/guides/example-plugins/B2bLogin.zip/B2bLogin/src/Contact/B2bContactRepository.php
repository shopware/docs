<?php declare(strict_types=1);

namespace B2bLogin\Contact;

use Doctrine\DBAL\Connection;
use PDO;
use Shopware\B2B\Acl\Framework\AclReadHelper;
use Shopware\B2B\Common\Repository\DbalHelper;
use Shopware\B2B\Company\Framework\CompanyFilterHelper;
use Shopware\B2B\Contact\Framework\ContactCompanyAssignmentFilter;
use Shopware\B2B\Contact\Framework\ContactCompanyInheritanceFilter;
use Shopware\B2B\Contact\Framework\ContactEntity;
use Shopware\B2B\Contact\Framework\ContactRepository;
use Shopware\B2B\Debtor\Framework\DebtorRepositoryInterface;
use Shopware\B2B\StoreFrontAuthentication\Framework\QuerySubShopExtenderInterface;
use Shopware\B2B\StoreFrontAuthentication\Framework\StoreFrontAuthenticationRepository;

class B2bContactRepository extends ContactRepository
{
    public const TABLE_NAME = 'b2b_debtor_contact';
    public const TABLE_ALIAS = 'contact';

    private Connection $connection;

    public function __construct(
        Connection $connection,
        DbalHelper $dbalHelper,
        DebtorRepositoryInterface $debtorRepository,
        StoreFrontAuthenticationRepository $authenticationRepository,
        AclReadHelper $aclReadHelper,
        ContactCompanyAssignmentFilter $contactCompanyAssignmentFilter,
        CompanyFilterHelper $companyFilterHelper,
        ContactCompanyInheritanceFilter $contactCompanyInheritanceFilter,
        QuerySubShopExtenderInterface $querySubShopExtender
    ) {
        parent::__construct(
            $connection,
            $dbalHelper,
            $debtorRepository,
            $authenticationRepository,
            $aclReadHelper,
            $contactCompanyAssignmentFilter,
            $companyFilterHelper,
            $contactCompanyInheritanceFilter,
            $querySubShopExtender
        );

        $this->connection = $connection;
    }

    public function fetchOneByStaffId(string $staffId): ContactEntity
    {
        $statement = $this->connection->createQueryBuilder()
            ->select('*')
            ->from(self::TABLE_NAME, self::TABLE_ALIAS)
            ->where(self::TABLE_ALIAS . '.staff_id = :staffId')
            ->setParameter('staffId', $staffId)
            ->execute();

        $contactData = $statement->fetch(PDO::FETCH_ASSOC);

        return $this->createContactByContactData($contactData, $staffId);
    }
}
