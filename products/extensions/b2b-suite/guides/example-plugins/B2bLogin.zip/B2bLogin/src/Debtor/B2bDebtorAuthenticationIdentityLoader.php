<?php declare(strict_types=1);

namespace B2bLogin\Debtor;

use Shopware\B2B\Common\IdValue;
use Shopware\B2B\Common\Repository\NotFoundException;
use Shopware\B2B\Debtor\BridgePlatform\DebtorAuthenticationIdentityLoader;
use Shopware\B2B\Debtor\BridgePlatform\DebtorRepository;
use Shopware\B2B\Debtor\Framework\DebtorIdentity;
use Shopware\B2B\StoreFrontAuthentication\Framework\AbstractCredentialsEntity;
use Shopware\B2B\StoreFrontAuthentication\Framework\Identity;
use Shopware\B2B\StoreFrontAuthentication\Framework\LoginContextService;

class B2bDebtorAuthenticationIdentityLoader extends DebtorAuthenticationIdentityLoader
{
    private DebtorRepository $debtorRepository;

    public function __construct(B2bDebtorRepository $debtorRepository)
    {
        $this->debtorRepository = $debtorRepository;
        parent::__construct($debtorRepository);
    }

    public function fetchIdentityByStaffId(string $staffId, LoginContextService $contextService, bool $isApi = false): Identity
    {
        $entity = $this->debtorRepository->fetchOneByStaffId($staffId);

        $authId = $contextService->getAuthId(DebtorRepository::class, $entity->id);

        return new DebtorIdentity($authId, IdValue::create($entity->id), DebtorRepository::TABLE_NAME, $entity, '', $isApi);
    }

    public function fetchIdentityByCredentials(AbstractCredentialsEntity $credentialsEntity, LoginContextService $contextService, bool $isApi = false): Identity
    {
        if (!isset($credentialsEntity->staffId) || !$credentialsEntity->staffId) {
            throw new NotFoundException('Unable to handle context');
        }

        return $this->fetchIdentityByStaffId($credentialsEntity->staffId, $contextService);
    }
}
