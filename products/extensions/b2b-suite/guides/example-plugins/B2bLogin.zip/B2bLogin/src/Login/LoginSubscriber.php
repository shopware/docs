<?php declare(strict_types=1);

namespace B2bLogin\Login;

use Shopware\B2B\Common\Repository\NotFoundException;
use Shopware\B2B\StoreFrontAuthentication\Framework\AuthenticationIdentityLoaderInterface;
use Shopware\B2B\StoreFrontAuthentication\Framework\CredentialsBuilderInterface;
use Shopware\B2B\StoreFrontAuthentication\Framework\LoginContextService;
use Shopware\Core\Checkout\Customer\Event\CustomerLoginEvent;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

class LoginSubscriber implements EventSubscriberInterface
{
    private CredentialsBuilderInterface $credentialBuilder;

    private AuthenticationIdentityLoaderInterface $identityChain;

    private LoginContextService $context;

    public function __construct(
        CredentialsBuilderInterface $credentialBuilder,
        AuthenticationIdentityLoaderInterface $identityChain,
        LoginContextService $context
    ) {
        $this->credentialBuilder = $credentialBuilder;
        $this->identityChain = $identityChain;
        $this->context = $context;
    }

    public static function getSubscribedEvents(): array
    {
        return [
            CustomerLoginEvent::class => ['updateEmail', 2],
        ];
    }

    public function updateEmail(CustomerLoginEvent $event): void
    {
        $customer = $event->getCustomer();
        $credential = $this->credentialBuilder->createCredentials(['staffId' => 'B-1']);

        try {
            $entity = $this->identityChain->fetchIdentityByCredentials($credential, $this->context, false);
        } catch (NotFoundException $e) {
            return;
        }
    }
}
