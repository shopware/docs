<?php declare(strict_types=1);

namespace B2bLogin;

use Doctrine\DBAL\Connection;
use Shopware\Core\Framework\Plugin;
use Shopware\Core\Framework\Plugin\Context\InstallContext;

class B2bLogin extends Plugin
{
    public function install(InstallContext $installContext): void
    {
        $connection = $this->container->get(Connection::class);
        $connection->executeStatement('
            ALTER TABLE b2b_debtor_contact
            ADD staff_id VARCHAR(255),

            ADD CONSTRAINT `dcstaff_id` UNIQUE (`staff_id`)
        ');

        $connection->executeStatement('
            SET @a = 0;
            UPDATE b2b_debtor_contact SET staff_id = CONCAT(\'A\', \'-\', @a:=@a+1);
        ');

        $connection->executeStatement('
            ALTER TABLE b2b_customer_data
            ADD staff_id VARCHAR(255),

            ADD CONSTRAINT `dcstaff_id` UNIQUE (`staff_id`)
        ');

        $connection->executeStatement('
            SET @a = 0;
            UPDATE customer SET staff_id = CONCAT(\'B\', \'-\', @a:=@a+1);
        ');
    }
}
