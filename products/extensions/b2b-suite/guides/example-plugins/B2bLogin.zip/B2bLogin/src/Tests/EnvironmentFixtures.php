<?php declare(strict_types=1);

namespace Shopware\B2BTest\ B2bLogin;

use Doctrine\DBAL\Connection;
use Shopware\B2B\Common\Testing\Fixture;

class EnvironmentFixtures extends Fixture
{
    protected function createValueIds(Connection $connection): array
    {
        return [];
    }

    protected function createSqlTemplate(): string
    {
        return <<<'SQL'
INSERT INTO b2b_store_front_auth (`id`, `context_owner_id`, `provider_key`, `provider_context`) VALUES
  (1, 1, 'Shopware\\B2B\\Debtor\\Framework\\DebtorRepository', 250)
  ,(2, 1, 'Shopware\\B2B\\Contact\\Framework\\ContactRepository', 11)
  ,(3, 1, 'Shopware\\B2B\\Contact\\Framework\\ContactRepository', 22)
  ,(4, 1, 'Shopware\\B2B\\Contact\\Framework\\ContactRepository', 33)
  ,(5, 1, 'Shopware\\B2B\\Contact\\Framework\\ContactRepository', 44)
  ,(6, 1, 'Shopware\\B2B\\Contact\\Framework\\ContactRepository', 55)
  ,(7, 1, 'Shopware\\B2B\\Contact\\Framework\\ContactRepository', 66)
  ,(8, 1, 'Shopware\\B2B\\Contact\\Framework\\ContactRepository', 77)
  ,(9, 1, 'Shopware\\B2B\\Contact\\Framework\\ContactRepository', 88)
  ,(10, 1, 'Shopware\\B2B\\Contact\\Framework\\ContactRepository', 99)
  ,(30, 30, 'Shopware\\B2B\\Debtor\\Framework\\DebtorRepository',   249)
  ,(31, 30, 'Shopware\\B2B\\Contact\\Framework\\ContactRepository', 1234)
  ,(32, 30, 'Shopware\\B2B\\Contact\\Framework\\ContactRepository', 101)
  ,(33, 30, 'Shopware\\B2B\\Contact\\Framework\\ContactRepository', 102)
  ,(34, 30, 'Shopware\\B2B\\Contact\\Framework\\ContactRepository', 103)
  ,(35, 30, 'Shopware\\B2B\\Contact\\Framework\\ContactRepository', 104)
  ,(36, 30, 'Shopware\\B2B\\Contact\\Framework\\ContactRepository', 105)
  ,(37, 30, 'Shopware\\B2B\\Contact\\Framework\\ContactRepository', 106)
  ,(38, 30, 'Shopware\\B2B\\Contact\\Framework\\ContactRepository', 107)
  ,(39, 30, 'Shopware\\B2B\\Contact\\Framework\\ContactRepository', 108)
  ,(41, 30, 'Shopware\\B2B\\Contact\\Framework\\ContactRepository', 109)
;

REPLACE INTO `b2b_debtor_contact` (`id`, `password`, `email`, `active`, `language`, `salutation`, `firstname`, `lastname`, `context_owner_id`, `auth_id`, staff_id) VALUES
  (11, 'a256a310bc1e5db755fd392c524028a8', 'contact1@example.com', 1, 0, 'mr', 'Tom', 'Contact1', 1, 2, 'A-1'),
  (22, 'a256a310bc1e5db755fd392c524028a8', 'contact2@example.com', 1, 0, 'mr', 'Tom', 'Contact2', 1, 3, 'A-2'),
  (33, 'a256a310bc1e5db755fd392c524028a8', 'contact3@example.com', 1, 0, 'mr', 'Max', 'Contact3', 1, 4, 'A-3'),
  (44, 'a256a310bc1e5db755fd392c524028a8', 'contact4@example.com', 1, 0, 'mr', 'Max', 'Contact4', 1, 5, 'A-4'),
  (45, 'a256a310bc1e5db755fd392c524028a8', 'contact5@example.com', 1, 0, 'mr', 'Max', 'Contact5', 1, 6, 'A-5'),
  (46, 'a256a310bc1e5db755fd392c524028a8', 'contact6@example.com', 1, 0, 'mr', 'Max', 'Contact6', 1, NULL, 'A-6'),
  (47, 'a256a310bc1e5db755fd392c524028a8', 'contact7@example.com', 1, 0, 'mr', 'Max', 'Contact7', 1, NULL, 'A-7'),
  (48, 'a256a310bc1e5db755fd392c524028a8', 'contact8@example.com', 1, 0, 'mr', 'Max', 'Contact8', 1, NULL, 'A-8'),
  (49, 'a256a310bc1e5db755fd392c524028a8', 'contact9@example.com', 1, 0, 'mr', 'Max', 'Contact9', 1, NULL, 'A-9'),
  (50, 'a256a310bc1e5db755fd392c524028a8', 'contact10@example.com', 1, 0, 'mr', 'Max', 'Contact10', 1, NULL, 'A-10'),
  (51, 'a256a310bc1e5db755fd392c524028a8', 'contact11@example.com', 1, 0, 'mr', 'Max', 'Contact11', 1, NULL, 'A-11'),
  (52, 'a256a310bc1e5db755fd392c524028a8', 'contact12@example.com', 1, 0, 'mr', 'Max', 'Contact12', 1, NULL, 'A-12'),
  (53, 'a256a310bc1e5db755fd392c524028a8', 'contact13@example.com', 1, 0, 'mr', 'Max', 'Contact13', 1, NULL, 'A-13'),
  (54, 'a256a310bc1e5db755fd392c524028a8', 'contact14@example.com', 1, 0, 'mr', 'Max', 'Contact14', 1, NULL, 'A-14'),
  (55, 'a256a310bc1e5db755fd392c524028a8', 'contact15@example.com', 1, 0, 'mr', 'Max', 'Contact15', 1, NULL, 'A-15'),
  (56, 'a256a310bc1e5db755fd392c524028a8', 'contact16@example.com', 1, 0, 'mr', 'Max', 'Contact16', 1, NULL, 'A-16'),
  (57, 'a256a310bc1e5db755fd392c524028a8', 'contact17@example.com', 1, 0, 'mr', 'Max', 'Contact17', 1, NULL, 'A-17'),
  (58, 'a256a310bc1e5db755fd392c524028a8', 'contact18@example.com', 1, 0, 'mr', 'Max', 'Contact18', 1, NULL, 'A-18'),
  (59, 'a256a310bc1e5db755fd392c524028a8', 'contact19@example.com', 1, 0, 'mr', 'Max', 'Contact19', 1, NULL, 'A-19'),
  (60, 'a256a310bc1e5db755fd392c524028a8', 'contact20@example.com', 1, 0, 'mr', 'Max', 'Contact20', 1, NULL, 'A-20'),
  (61, 'a256a310bc1e5db755fd392c524028a8', 'contact21@example.com', 0, 0, 'mr', 'Max', 'Contact21', 1, NULL, 'A-21'),
  (62, 'a256a310bc1e5db755fd392c524028a8', 'contact23@example.com', 0, 0, 'mr', 'Max', 'Contact23', 1, NULL, 'A-22');

INSERT INTO `b2b_acl_contact_address` (`entity_id`, `referenced_entity_id`, `grantable`) VALUES
  (33, 28, 1),
  (33, 41, 1),
  (33, 42, 1),
  (33, 43, 1),
  (33, 44, 1),
  (33, 45, 1),
  (33, 46, 1),
  (33, 47, 1),
  (33, 48, 1),
  (33, 49, 1),
  (33, 50, 1),
  (33, 51, 1),
  (11, 28, 1),
  (11, 41, 1),
  (11, 42, 0),
  (11, 43, 1),
  (11, 44, 1),
  (11, 45, 0),
  (11, 46, 1),
  (11, 47, 1),
  (11, 48, 0),
  (11, 49, 1),
  (11, 50, 1),
  (11, 51, 1),
  (11, 35, 1);
SQL;
    }
}
