<?php declare(strict_types=1);

namespace B2bLogin\Debtor;

use Doctrine\DBAL\Connection;
use PDO;
use Shopware\B2B\Common\Repository\NotFoundException;
use Shopware\B2B\Debtor\BridgePlatform\DebtorEntityFactory;
use Shopware\B2B\Debtor\BridgePlatform\DebtorRepository;
use Shopware\B2B\Debtor\Framework\DebtorEntity;
use Shopware\B2B\Shop\BridgePlatform\ContextProvider;
use function sprintf;

class B2bDebtorRepository extends DebtorRepository
{
    private Connection $connection;

    public function __construct(
        Connection $connection,
        ContextProvider $contextProvider,
        DebtorEntityFactory $debtorEntityFactory
    ) {
        $this->connection = $connection;
        parent::__construct($connection, $contextProvider, $debtorEntityFactory);
    }

    /**
     * @throws NotFoundException
     */
    public function fetchOneByStaffId(string $staffId): DebtorEntity
    {
        $statement = $this->connection->createQueryBuilder()
            ->select(self::TABLE_ALIAS . '.*')
            ->from(self::TABLE_NAME, 'customer')
            ->innerJoin(self::TABLE_ALIAS, 'b2b_customer_data', 'b2bcustomer', 'customer.id = b2bcustomer.customer_id')
            ->where('b2bcustomer.staff_id = :staffId')
            ->andWhere('b2bcustomer.is_debtor = 1')
            ->setParameter('staffId', $staffId)
            ->execute();

        $user = $statement->fetch(PDO::FETCH_ASSOC);

        if (!$user) {
            throw new NotFoundException(sprintf('Debtor not found for %s', $staffId));
        }

        return (new DebtorEntity())->fromDatabaseArray($user);
    }
}
