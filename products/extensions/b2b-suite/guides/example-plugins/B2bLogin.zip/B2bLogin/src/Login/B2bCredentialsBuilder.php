<?php declare(strict_types=1);

namespace B2bLogin\Login;

use Shopware\B2B\Common\IdValue;
use Shopware\B2B\StoreFrontAuthentication\Framework\AbstractCredentialsEntity;
use Shopware\B2B\StoreFrontAuthentication\Framework\CredentialsBuilderInterface;

class B2bCredentialsBuilder implements CredentialsBuilderInterface
{
    public function createCredentials(array $parameters): AbstractCredentialsEntity
    {
        $entity = new ExtendedCredentialsEntity();
        $entity->staffId = $parameters['staffId'];

        return $entity;
    }

    public function createCredentialsByEmail(string $email): AbstractCredentialsEntity
    {
        // TODO: Implement createCredentialsByEmail() method.
    }

    public function createCredentialsByUserId(IdValue $userId): AbstractCredentialsEntity
    {
        // TODO: Implement createCredentialsByUserId() method.
    }
}
