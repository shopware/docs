<?php declare(strict_types=1);

namespace B2bLogin\Login;

use Shopware\B2B\StoreFrontAuthentication\BridgePlatform\CredentialsEntity;

class ExtendedCredentialsEntity extends CredentialsEntity
{
    public string $staffId;
}
