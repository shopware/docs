<?php declare(strict_types=1);

namespace B2bTemplateExtension;

use Shopware\Core\Framework\Plugin;

class B2bTemplateExtension extends Plugin
{
    public function getParent()
    {
        parent::getParent();
    }
}
