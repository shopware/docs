<?php declare(strict_types=1);

namespace B2bAuditLog\Controllers\Frontend;

use Shopware\B2B\AuditLog\Framework\AuditLogEntity;
use Shopware\B2B\AuditLog\Framework\AuditLogIndexEntity;
use Shopware\B2B\AuditLog\Framework\AuditLogRepository;
use Shopware\B2B\AuditLog\Framework\AuditLogSearchStruct;
use Shopware\B2B\AuditLog\Framework\AuditLogService;
use Shopware\B2B\AuditLog\Framework\AuditLogValueDiffEntity;
use Shopware\B2B\Common\Controller\GridHelper;
use Shopware\B2B\Common\IdValue;
use Shopware\B2B\Common\MvcExtension\Request;
use Shopware\B2B\Currency\Framework\CurrencyService;
use Shopware\B2B\StoreFrontAuthentication\Framework\AuthenticationService;

class AuditLogController
{
    public const REFERENCE_TABLE = 'reference_table';

    public const REFERENCE_ID = 100;

    public const REFERENCE_SUB_TABLE = 'reference_sub_table';

    public const REFERENCE_SUB_ID = 200;

    private AuthenticationService $authenticationService;

    private AuditLogRepository $auditLogRepository;

    private GridHelper $auditLogGridHelper;

    private AuditLogService $auditLogService;

    private CurrencyService $currencyService;

    public function __construct(
        AuthenticationService $authenticationService,
        AuditLogService $auditLogService,
        AuditLogRepository $auditLogRepository,
        GridHelper $auditLogGridHelper,
        CurrencyService $currencyService
    ) {
        $this->authenticationService = $authenticationService;
        $this->auditLogRepository = $auditLogRepository;
        $this->auditLogGridHelper = $auditLogGridHelper;
        $this->auditLogService = $auditLogService;
        $this->currencyService = $currencyService;
    }

    public function indexAction(): void
    {
        // nth
    }

    public function gridAction(Request $request): array
    {
        $auditLogSearchStruct = new AuditLogSearchStruct();
        $currencyContext = $this->currencyService->createCurrencyContext();

        $this->auditLogGridHelper
            ->extractSearchDataInStoreFront($request, $auditLogSearchStruct);

        $auditLogs = $this->auditLogRepository
            ->fetchList(self::REFERENCE_TABLE, IdValue::create(self::REFERENCE_ID), $auditLogSearchStruct, $currencyContext);

        $totalCount = $this->auditLogRepository
            ->fetchTotalCount(self::REFERENCE_TABLE, IdValue::create(self::REFERENCE_ID), $auditLogSearchStruct);

        $maxPage = $this->auditLogGridHelper
            ->getMaxPage($totalCount);

        $currentPage = (int) $request->getParam('page', 1);

        $gridState = $this->auditLogGridHelper
            ->getGridState($request, $auditLogSearchStruct, $auditLogs, $maxPage, $currentPage);

        return [
            'gridState' => $gridState,
        ];
    }

    public function createAction(Request $request): array
    {
        $identity = $this->authenticationService
            ->getIdentity();

        $auditLogValue = new AuditLogValueDiffEntity();
        $auditLogValue->newValue = 'newValue';
        $auditLogValue->oldValue = 'oldValue';

        $auditLog = new AuditLogEntity();
        $auditLog->logValue = $auditLogValue;
        $auditLog->logType = 'logType';

        $auditLogIndex = new AuditLogIndexEntity();
        $auditLogIndex->referenceId = IdValue::create(self::REFERENCE_ID);
        $auditLogIndex->referenceTable = self::REFERENCE_TABLE;

        $auditLogSubIndex = new AuditLogIndexEntity();
        $auditLogSubIndex->referenceId = IdValue::create(self::REFERENCE_SUB_ID);
        $auditLogSubIndex->referenceTable = self::REFERENCE_SUB_TABLE;

        $auditLog = $this->auditLogService
            ->createAuditLog($auditLog, $identity, [$auditLogIndex, $auditLogSubIndex]);

        return [
            'auditLog' => $auditLog,
        ];
    }
}
