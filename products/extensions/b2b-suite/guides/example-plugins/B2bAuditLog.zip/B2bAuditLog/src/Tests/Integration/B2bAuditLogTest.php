<?php declare(strict_types=1);

namespace B2bAuditLog\Tests;

use Shopware\B2B\Common\Testing\CommonTestFixtures;
use Shopware\B2B\Common\Testing\WebTestCaseTrait;

class B2bAuditLogTest extends \PHPUnit\Framework\TestCase
{
    use WebTestCaseTrait;

    public function test_index_action(): void
    {
        $this->disableCommonFixtures(false);
        $this->importFixture(new CommonTestFixtures());
        $this->performB2bDebtorLogin();

        $client = $this->createClient();
        $client->request('GET', '/b2bauditlog/');

        self::assertEquals(200, $client->getResponse()->getStatusCode());
        self::assertContains('b2bauditlog', $client->getResponse()->getContent());
    }

    public function test_create_action(): void
    {
        $this->disableCommonFixtures(false);
        $this->importFixture(new CommonTestFixtures());
        $this->performB2bDebtorLogin();

        $client = $this->createClient();
        $client->request('GET', '/b2bauditlog/create');

        self::assertEquals(200, $client->getResponse()->getStatusCode());
        self::assertContains('Audit Log successfully created!', $client->getResponse()->getContent());
    }
}
