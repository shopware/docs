<?php declare(strict_types=1);

namespace Shopware\B2BTest\ ServiceExtension;

use Doctrine\DBAL\Connection;
use Shopware\B2B\Common\Testing\Fixture;

class ServiceExtensionFixtures extends Fixture
{
    protected function createValueIds(Connection $connection): array
    {
        return [];
    }

    protected function createSqlTemplate(): string
    {
        return <<<'SQL'
INSERT INTO `b2b_acl_contact_address` (`entity_id`, `referenced_entity_id`, `grantable`) VALUES
  (33, 28, 1),
  (33, 41, 1),
  (33, 42, 1),
  (33, 43, 1),
  (33, 44, 1),
  (33, 45, 1),
  (33, 46, 1),
  (33, 47, 1),
  (33, 48, 1),
  (33, 49, 1),
  (33, 50, 1),
  (33, 51, 1),
  (11, 28, 1),
  (11, 41, 1),
  (11, 42, 0),
  (11, 43, 1),
  (11, 44, 1),
  (11, 45, 0),
  (11, 46, 1),
  (11, 47, 1),
  (11, 48, 0),
  (11, 49, 1),
  (11, 50, 1),
  (11, 51, 1),
  (11, 35, 1);

INSERT INTO `b2b_acl_route_privilege` (`id`, `resource_name`, `privilege_type`) VALUES
  (5, 'resource', 'privilege');

INSERT INTO `b2b_acl_route` (`id`, `controller`, `action`, `privilege_id`) VALUES
  (1, 'unit', 'test', 5);

INSERT INTO `b2b_role` (`id`, `name`, `context_owner_id`, `left`, `right`, `level`) VALUES
  (11, 'Einkauf',         1,   1, 24, 0),
  (22, 'Einkauf',         1,   2,  3, 1),
  (33, 'Verkauf',         1,   4,  5, 1),
  (44, 'Core',            1,   6,  7, 1),
  (55, 'Enterprise',      1,   8,  9, 1),
  (66, 'Qa',              1,  10, 11, 1),
  (77, 'Einkauf',         1,  12, 13, 1),
  (88, 'Verkauf',         1,  14, 15, 1),
  (99, 'Core',            1,  16, 17, 1),
  (111, 'Enterprise',     1,  18, 19, 1),
  (122, 'Aa',             1,  20, 21, 1),
  (133, 'Za',             1,  22, 23, 1),
  (144, 'Debtor2role',    40,  1,  2, 1);

INSERT INTO `b2b_role_contact` (`id`, `role_id`, `debtor_contact_id`) VALUES
(11, 11, 11),
(22, 22,22),
(33, 33,33);
SQL;
    }
}
