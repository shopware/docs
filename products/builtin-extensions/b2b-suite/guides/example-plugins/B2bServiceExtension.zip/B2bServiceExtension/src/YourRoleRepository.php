<?php declare(strict_types=1);

namespace B2bServiceExtension;

use Shopware\B2B\Contact\Framework\ContactRepository;
use Shopware\B2B\Role\Framework\RoleEntity;
use Shopware\B2B\Role\Framework\RoleRepository;
use Shopware\B2B\StoreFrontAuthentication\Framework\OwnershipContext;

class YourRoleRepository extends RoleRepository
{
    private ContactRepository $contactRepository;

    public function __construct(ContactRepository $contactRepository)
    {
        $this->contactRepository = $contactRepository;
    }

    public function updateRole(RoleEntity $role, OwnershipContext $ownershipContext): RoleEntity
    {
        return parent::updateRole($role, $ownershipContext);
    }
}
