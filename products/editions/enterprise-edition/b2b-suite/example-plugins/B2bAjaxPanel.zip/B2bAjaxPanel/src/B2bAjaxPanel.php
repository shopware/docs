<?php declare(strict_types=1);

namespace B2bAjaxPanel;

use Shopware\Core\Framework\Plugin;

class B2bAjaxPanel extends Plugin
{
}
