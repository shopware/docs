<?php declare(strict_types=1);

namespace B2bAjaxPanel\Controllers\Frontend;

use Shopware\B2B\Common\MvcExtension\Request;

class B2bAjaxPanel
{
    public function indexAction(): void
    {
        // nothing to do
    }

    public function navAction(): void
    {
        // nothing to do
    }

    public function subAction(Request $request): array
    {
        return ['isPost' => $request->isPost(), 'name' => $request->getParam('name', 'nobody')];
    }
}
