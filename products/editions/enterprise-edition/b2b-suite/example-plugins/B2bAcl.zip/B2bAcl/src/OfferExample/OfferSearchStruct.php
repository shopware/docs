<?php declare(strict_types=1);

namespace B2bAcl\OfferExample;

use Shopware\B2B\Common\Repository\SearchStruct;

class OfferSearchStruct extends SearchStruct
{
}
