<?php declare(strict_types=1);

namespace B2bAuth\Controllers\Frontend;

use Shopware\B2B\StoreFrontAuthentication\Framework\AuthenticationService;
use Shopware\B2B\StoreFrontAuthentication\Framework\CredentialsBuilderInterface;
use Shopware\B2B\StoreFrontAuthentication\Framework\LoginService;

class B2bAuthController
{
    private AuthenticationService $authenticationService;

    private LoginService $loginService;

    private CredentialsBuilderInterface $credentialsBuilder;

    public function __construct(
        AuthenticationService $authenticationService,
        LoginService $loginService,
        CredentialsBuilderInterface $credentialsBuilder
    ) {
        $this->authenticationService = $authenticationService;
        $this->loginService = $loginService;
        $this->credentialsBuilder = $credentialsBuilder;
    }

    public function indexAction(): void
    {
    }

    public function contactAction(): array
    {
        $credentials = $this->credentialsBuilder->createCredentialsByEmail('contact1@example.com');

        $this->loginService->setIdentityFor($credentials);

        $identity = $this->authenticationService->getIdentity();

        return [
            'identity' => $identity,
            'contextOwner' => $this->authenticationService->getIdentityByAuthId($identity->getOwnershipContext()->contextOwnerId),
        ];
    }

    public function debtorAction(): array
    {
        $credentials = $this->credentialsBuilder->createCredentialsByEmail('debtor@example.com');

        $this->loginService->setIdentityFor($credentials);

        $identity = $this->authenticationService->getIdentity();

        return [
            'identity' => $identity,
            'contextOwner' => $this->authenticationService->getIdentityByAuthId($identity->getOwnershipContext()->contextOwnerId),
        ];
    }
}
