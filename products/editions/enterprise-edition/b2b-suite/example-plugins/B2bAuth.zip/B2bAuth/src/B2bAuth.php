<?php declare(strict_types=1);

namespace B2bAuth;

use Shopware\B2B\Common\B2BContainerBuilder;
use Shopware\Core\Framework\Plugin;
use SwagB2bPlatform\Resources\DependencyInjection\SwagB2bPlatformApiConfiguration;
use SwagB2bPlatform\Resources\DependencyInjection\SwagB2bPlatformFrontendConfiguration;
use Symfony\Component\DependencyInjection\ContainerBuilder;

class B2bAuth extends Plugin
{
    public function build(ContainerBuilder $container): void
    {
        $containerBuilder = B2BContainerBuilder::create();
        $containerBuilder->addConfiguration(new SwagB2bPlatformApiConfiguration());
        $containerBuilder->addConfiguration(new SwagB2bPlatformFrontendConfiguration());
        $containerBuilder->registerConfigurations($container);

        parent::build($container);
    }
}
